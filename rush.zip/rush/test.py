#key
from time import sleep
#显示屏
from pynq.overlays.base import BaseOverlay
from pynq.lib.video import *
import numpy as np
from PIL import Image,ImageFont, ImageDraw

#模型代码

import openpose_img as pose
import cv2 as cv
import math

#模型
boylongshirtsize={'S':[64,42,60],'M':[66,44,62],'L':[68,45,63],'XL':[70,47,64],'XXL':[72,48,65]}
boyshortshirtsize={'S':[67,42,21],'M':[69,44,21],'L':[71,45,22],'XL':[73,47,23],'XXL':[75,48,23]}
boyshortpantssize={'S':[37,50],'M':[38.5,52],'L':[40,27],'XL':[42,28],'XXL':[44,28]}
boylongpantssize={'S':[35,96],'M':[36.5,98],'L':[38,101],'XL':[40,104],'XXL':[42,106]}
girlshortpantssize={'S':[35,32],'M':[36.5,33],'L':[38,34],'XL':[40,34],'XXL':[42,35]}
girllongpantssize={'S':[33,96],'M':[34.5,98],'L':[36,101],'XL':[37.5,103],'XXL':[39,106]}
girllongshirtsize={'S':[56,35.6,56.7],'M':[58,37,58],'L':[60,38.4,59.3],'XL':[62,39.8,60.6],'XXL':[64,41.2,61.9]}
girlshortshirtsize={'S':[60,37,18],'M':[62,38,18],'L':[64,39,19],'XL':[66,41,19],'XXL':[68,42,20]}

kshoulder=1.105
kup=0.990
khip=1.300
kdown=1.184
kknee=1.248
kbow=1.048
kwrist=0.970


#SVD最小二乘三角解
def getRealPoint(pointl, pointr, R, T, camtl, camtr):
    leftRT = np.array([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0]], dtype=np.float64)
    rightRT = np.concatenate((R, T), axis=1)
    leftRT = np.matmul(camtl, leftRT)
    rightRT = np.matmul(camtr, rightRT)
    A = np.zeros((4, 3), dtype=np.float64)
    B = np.zeros((4, 1), dtype=np.float64)
    A[0, 0] = pointl[0] * leftRT[2, 0] - leftRT[0, 0]
    A[0, 1] = pointl[0] * leftRT[2, 1] - leftRT[0, 1]
    A[0, 2] = pointl[0] * leftRT[2, 2] - leftRT[0, 2]

    A[1, 0] = pointl[1] * leftRT[2, 0] - leftRT[1, 0]
    A[1, 1] = pointl[1] * leftRT[2, 1] - leftRT[1, 1]
    A[1, 2] = pointl[1] * leftRT[2, 2] - leftRT[1, 2]

    A[2, 0] = pointr[0] * rightRT[2, 0] - rightRT[0, 0]
    A[2, 1] = pointr[0] * rightRT[2, 1] - rightRT[0, 1]
    A[2, 2] = pointr[0] * rightRT[2, 2] - rightRT[0, 2]

    A[3, 0] = pointr[1] * rightRT[2, 0] - rightRT[1, 0]
    A[3, 1] = pointr[1] * rightRT[2, 1] - rightRT[1, 1]
    A[3, 2] = pointr[1] * rightRT[2, 2] - rightRT[1, 2]

    B[0, 0] = leftRT[0, 3] - pointl[0] * leftRT[2, 3]
    B[1, 0] = leftRT[1, 3] - pointl[1] * leftRT[2, 3]
    B[2, 0] = rightRT[0, 3] - pointr[0] * rightRT[2, 3]
    B[3, 0] = rightRT[1, 3] - pointr[1] * rightRT[2, 3]
    pt = np.zeros((3, 1), dtype=np.float64)
    cv.solve(A, B, pt, cv.DECOMP_SVD)
    return pt
#检测返回骨骼点数据
def stero_pose_cal(imgl, imgr, camtl, camtr, disl, disr, R, T):
    sitePoints = []
    pariPoints = []
    im_left, pointsl = pose.getPoseSite(pose.args, pose.net, imgl)
    im_right, pointsr = pose.getPoseSite(pose.args, pose.net, imgr)
    print('left')
    print(pointsl)
    print('right')
    print(pointsr)
    cv.imwrite('left.jpg', im_left)
    cv.imwrite('right.jpg', im_right)
    for i in range(len(pointsl)):
        if pointsl[i] and pointsr[i]:
            ptr = np.array([[pointsr[i]]], dtype=np.float32)
            ptr = cv.undistortPoints(ptr, camtr, disr)
            ptl = np.array([[pointsl[i]]], dtype=np.float32)
            ptl = cv.undistortPoints(ptl, camtl, disl)
            ptl = ptl.reshape(2, 1)
            ptl = np.matmul(camtl, [ptl[0], ptl[1], 1])
            ptr = ptr.reshape(2, 1)
            ptr = np.matmul(camtr, [ptr[0], ptr[1], 1])
            sitePoints.append(getRealPoint(ptl, ptr, R, T, camtl, camtr))
            pariPoints.append([pointsl[i], pointsr[i]])
        else:
            pariPoints.append(None)
            sitePoints.append(None)
    return sitePoints,pointsl,pointsr
#保存检测图
def combine_photo(arr):
    #arr是一个列表，里面是两个图片的路径，例如["p1.png", 'p2.png']

    toImage = Image.new('RGB', (1280, 480))
    img1 = Image.open(arr[0])
    img12 = Image.open(arr[1])
    toImage.paste(img1, (0, 0))
    toImage.paste(img12, (640, 0))
    toImage=toImage.resize((640,480))
    toImage.save( "ouput.jpg")
#实际处理运行数据
def process_photo(im_left,im_right):
            # 标定数据
            T = np.array([[-122.05958], [0.12940] ,[3.23734]])
            rec= np.array([-0.01341 ,0.00975, -0.00264])
            R = cv.Rodrigues(rec)[0]
            cameraMatrix1 = np.array([[623.10365, 0., 505.06782],
                             [0., 621.77815, 365.95727],
                             [0., 0., 1.]])
            cameraMatrix2 = np.array([[624.11073, 0., 502.74570],
                             [0.,  620.37626, 346.47877],
                             [0.,0.,1.]])
            distCoeffs1 = np.array([ 0.01310 , 0.02113 , 0.00002 ,  0.01012, 0.00000])
            distCoeffs2 = np.array([0.04871 ,  -0.04216 ,  -0.00197 ,  0.00972 , 0.00000 ])
            # 进行图像识别计算
            sitePoints,pointleft,pointright = stero_pose_cal(im_left, im_right, cameraMatrix1,
                                        cameraMatrix2,
                                        distCoeffs1, distCoeffs2,
                                        R, T)

            # 获得相关的特征点
            print(sitePoints)
            print(sitePoints[10])
            print(sitePoints[13])

            return sitePoints,pointleft,pointright
'利用三维图坐标返回参数'
#返回身高
def shenggao(sitePoints):
    anklenum = 0
    if sitePoints[19] is not None:
        head = sitePoints[19]
    if sitePoints[10] is not None:
        rightankle = sitePoints[10]
        anklenum += 1
    else:
        rightankle = np.array([0, 0, 0])
    if sitePoints[13] is not None:
        leftankle = sitePoints[13]
        anklenum += 1
    else:
        leftankle = np.array([0, 0, 0])
    ankle = (rightankle + leftankle) / anklenum
    len= math.sqrt((head[1] - ankle[1]) * (head[1] - ankle[1]))
    return len
#返回上衣参数
def shangyi(sitePoints,type,sex):
    hipnum=0
    #脖子
    if sitePoints[1] is not None:
        neck = sitePoints[1]
    #胯骨
    if sitePoints[8] is not None:
        righthip = sitePoints[8]
        hipnum += 1
    else:
        righthip = np.array([0, 0, 0])
    if sitePoints[11] is not None:
        lefthip = sitePoints[11]
        hipnum += 1
    else:
        lefthip = np.array([0, 0, 0])
    #肩膀
    if sitePoints[2] is not None:
        rightshoulder = sitePoints[2]
    else:
        rightshoulder = np.array([0, 0, 0])
    if sitePoints[5] is not None:
        leftshoulder = sitePoints[5]
    else:
        leftshoulder = np.array([0, 0, 0])
    #手腕
    if sitePoints[4] is not None:
        rightwrist = sitePoints[4]
    else:
        rightwrist = np.array([0, 0, 0])
    if sitePoints[7] is not None:
        leftwrist = sitePoints[7]
    else:
        leftwrist = np.array([0, 0, 0])
    #肘部
    if sitePoints[3] is not None:
        rightbow = sitePoints[3]
    else:
        rightbow = np.array([0, 0, 0])
    if sitePoints[6] is not None:
        leftbow = sitePoints[6]
    else:
        leftbow = np.array([0, 0, 0])


    hip = (righthip + lefthip) / hipnum

    realbody = math.sqrt((neck[0] - hip[0]) * (neck[0] - hip[0]) + (neck[1] - hip[1]) * (neck[1] - hip[1]))
    realshoulder= math.sqrt((leftshoulder[0] - rightshoulder[0]) * (leftshoulder[0] - rightshoulder[0]) + (leftshoulder[1] - rightshoulder[1]) * (leftshoulder[1] - rightshoulder[1]))
    realbow=(math.sqrt((leftshoulder[0] - leftbow[0]) * (leftshoulder[0] - leftbow[0]) + (leftshoulder[1] - leftbow[1]) * (leftshoulder[1] - leftbow[1]))+\
             math.sqrt((rightshoulder[0] - rightbow[0]) * (rightshoulder[0] - rightbow[0]) + (rightshoulder[1] - rightbow[1]) * (rightshoulder[1] - rightbow[1])))/2
    realwrist=(math.sqrt((leftshoulder[0] - leftwrist[0]) * (leftshoulder[0] - leftwrist[0]) + (leftshoulder[1] - leftwrist[1]) * (leftshoulder[1] - leftwrist[1]))+\
               math.sqrt((rightshoulder[0] - rightwrist[0]) * (rightshoulder[0] - rightwrist[0]) + (rightshoulder[1] - rightwrist[1]) * (rightshoulder[1] - rightwrist[1])))/2
    flag=100000
    if(sex==0):
        if (type == 0):
            for key0 in boyshortshirtsize.keys():
                flagnow = math.fabs(realbody - boyshortshirtsize[key0][0]) / boyshortshirtsize[key0][0] \
                          + math.fabs(realshoulder - boyshortshirtsize[key0][1]) / boyshortshirtsize[key0][1] \
                          + math.fabs(realbow - boyshortshirtsize[key0][2]) / boyshortshirtsize[key0][2]
                if (flagnow < flag):
                    size = key0
            return realbody, realshoulder, realwrist, size
        else:
            for key0 in boylongshirtsize.keys():
                flagnow = math.fabs(realbody - boylongshirtsize[key0][0]) / boylongshirtsize[key0][0] \
                          + math.fabs(realshoulder - boylongshirtsize[key0][1]) / boylongshirtsize[key0][1] \
                          + math.fabs(realwrist - boylongshirtsize[key0][2]) / boylongshirtsize[key0][2]
                if (flagnow < flag):
                    size = key0
            return realbody, realshoulder, realbow, size
    else:
        if (type == 0):
            for key0 in girlshortshirtsize.keys():
                flagnow = math.fabs(realbody - girlshortshirtsize[key0][0]) / girlshortshirtsize[key0][0] \
                          + math.fabs(realshoulder - girlshortshirtsize[key0][1]) / girlshortshirtsize[key0][1] \
                          + math.fabs(realbow - girlshortshirtsize[key0][2]) / girlshortshirtsize[key0][2]
                if (flagnow < flag):
                    size = key0
            return realbody, realshoulder, realwrist, size
        else:
            for key0 in girllongshirtsize.keys():
                flagnow = math.fabs(realbody - girllongshirtsize[key0][0]) / girllongshirtsize[key0][0] \
                          + math.fabs(realshoulder - girllongshirtsize[key0][1]) / girllongshirtsize[key0][1] \
                          + math.fabs(realwrist - girllongshirtsize[key0][2]) / girllongshirtsize[key0][2]
                if (flagnow < flag):
                    size = key0
            return realbody, realshoulder, realbow, size
#返回裤子参数
def kuzi(sitePoints,type,sex):
    #胯骨
    if sitePoints[8] is not None:
        righthip = sitePoints[8]
    else:
        righthip = np.array([0, 0, 0])
    if sitePoints[11] is not None:
        lefthip = sitePoints[11]
    #膝盖
    if sitePoints[9] is not None:
        rightknee = sitePoints[9]
    else:
        rightknee = np.array([0, 0, 0])
    if sitePoints[12] is not None:
        leftknee = sitePoints[12]
    else:
        leftknee = np.array([0, 0, 0])
    #脚踝
    if sitePoints[10] is not None:
        rightankle = sitePoints[10]
    else:
        rightankle = np.array([0, 0, 0])
    if sitePoints[12] is not None:
        leftankle = sitePoints[12]
    else:
        leftankle = np.array([0, 0, 0])
    realhip=math.sqrt((lefthip[0] - righthip[0]) * (lefthip[0] - righthip[0]) + (lefthip[1] - righthip[1]) * (lefthip[1] - righthip[1]))
    realankle=(math.sqrt((lefthip[0] - leftankle[0]) * (lefthip[0] - leftankle[0]) + (lefthip[1] - leftankle[1]) * (lefthip[1] - leftankle[1]))+\
               math.sqrt((righthip[0] - rightankle[0]) * (righthip[0] - rightankle[0]) + (righthip[1] - rightankle[1]) * (righthip[1] - rightankle[1])))/2
    realknee=(math.sqrt((lefthip[0] - leftknee[0]) * (lefthip[0] - leftknee[0]) + (lefthip[1] - leftknee[1]) * (lefthip[1] - leftknee[1]))+\
               math.sqrt((righthip[0] - rightknee[0]) * (righthip[0] - rightknee[0]) + (righthip[1] - rightknee[1]) * (righthip[1] - rightknee[1])))/2
    flag=100000
    if(sex==0):
        if (type == 0):
            for key0 in boyshortpantssize.keys():
                flagnow = math.fabs(realhip - boyshortpantssize[key0][0]) / boyshortpantssize[key0][0] \
                          + math.fabs(realknee - boyshortpantssize[key0][1]) / boyshortpantssize[key0][1]
                if (flagnow < flag):
                    size = key0
            return realhip, realknee, size
        else:
            for key0 in boylongpantssize.keys():
                flagnow = math.fabs(realhip - boylongpantssize[key0][0]) / boylongpantssize[key0][0] \
                          + math.fabs(realankle - boylongpantssize[key0][1]) / boylongpantssize[key0][1]
                if (flagnow < flag):
                    size = key0
            return realhip, realankle, size
    else:
        if (type == 0):
            for key0 in girlshortpantssize.keys():
                flagnow = math.fabs(realhip - girlshortpantssize[key0][0]) / girlshortpantssize[key0][0] \
                          + math.fabs(realknee - girlshortpantssize[key0][1]) / girlshortpantssize[key0][1]
                if (flagnow < flag):
                    size = key0
            return realhip, realknee, size
        else:
            for key0 in boylongpantssize.keys():
                flagnow = math.fabs(realhip - girllongpantssize[key0][0]) / girllongpantssize[key0][0] \
                          + math.fabs(realankle - girllongpantssize[key0][1]) / girllongpantssize[key0][1]
                if (flagnow < flag):
                    size = key0
            return realhip, realankle, size
'利用图片比例尺返回参数'
def shenggao1(left,right):
    anklenum1 = 0
    if left[19] is not None:
        head1 = left[19]
    if left[10] is not None:
        rightankle1 = left[10]
        anklenum1 += 1
    else:
        rightankle1 = np.array([0, 0])
    if left[13] is not None:
        leftankle1 = left[13]
        anklenum1 += 1
    else:
        leftankle1 = np.array([0, 0])
    ankle1 = (rightankle1[1] + leftankle1[1]) / anklenum1
    len1= math.fabs(head1[1]-ankle1)
    anklenum2 = 0
    if right[19] is not None:
        head2 = right[19]
    if right[10] is not None:
        rightankle2 = right[10]
        anklenum2 += 1
    else:
        rightankle2 = np.array([0, 0])
    if right[13] is not None:
        leftankle2 = right[13]
        anklenum2 += 1
    else:
        leftankle2 = np.array([0, 0])
    ankle2 = (rightankle2[1] + leftankle2[1]) / anklenum2
    len2 = math.fabs(head2[1]-ankle2)
    len=(len1+len2)/2
    return len
#返回上衣参数
def shangyi1(left,right,height,heightpoint,type,sex):
    hipnum1=0
    #脖子
    if left[1] is not None:
        neck1 = left[1]
    #胯骨
    if left[8] is not None:
        righthip1 = left[8]
        hipnum1 += 1
    else:
        righthip1 = np.array([0, 0])
    if left[11] is not None:
        lefthip1 = left[11]
        hipnum1 += 1
    else:
        lefthip1 = np.array([0, 0])
    #肩膀
    if left[2] is not None:
        rightshoulder1 = left[2]
    else:
        rightshoulder1 = np.array([0, 0])
    if left[5] is not None:
        leftshoulder1 = left[5]
    else:
        leftshoulder1 = np.array([0, 0])
    #手腕
    if left[4] is not None:
        rightwrist1 = left[4]
    else:
        rightwrist1 = np.array([0, 0])
    if left[7] is not None:
        leftwrist1 = left[7]
    else:
        leftwrist1 = np.array([0, 0])
    #肘部
    if left[3] is not None:
        rightbow1 = left[3]
    else:
        rightbow1 = np.array([0, 0])
    if left[6] is not None:
        leftbow1 = left[6]
    else:
        leftbow1 = np.array([0, 0])


    hip1 = (righthip1[1] + lefthip1[1])/hipnum1

    realbody1 = math.fabs(hip1-neck1[1])
    realshoulder1=math.fabs(leftshoulder1[0]-rightshoulder1[0])
    realbow1=(math.sqrt((leftshoulder1[0] - leftbow1[0]) * (leftshoulder1[0] - leftbow1[0]) + (leftshoulder1[1] - leftbow1[1]) * (leftshoulder1[1] - leftbow1[1]))+\
              math.sqrt((rightshoulder1[0] - rightbow1[0]) * (rightshoulder1[0] - rightbow1[0]) + (rightshoulder1[1] - rightbow1[1]) * (rightshoulder1[1] - rightbow1[1])))/2
    realwrist1=(math.sqrt((leftshoulder1[0] - leftwrist1[0]) * (leftshoulder1[0] - leftwrist1[0]) + (leftshoulder1[1] - leftwrist1[1]) * (leftshoulder1[1] - leftwrist1[1]))+\
               math.sqrt((rightshoulder1[0] - rightwrist1[0]) * (rightshoulder1[0] - rightwrist1[0]) + (rightshoulder1[1] - rightwrist1[1]) * (rightshoulder1[1] - rightwrist1[1])))/2

    hipnum2 = 0
    # 脖子
    if right[1] is not None:
        neck2 = right[1]
    # 胯骨
    if right[8] is not None:
        righthip2 = right[8]
        hipnum2 += 1
    else:
        righthip2 = np.array([0,0])
    if right[11] is not None:
        lefthip2 = right[11]
        hipnum2 += 1
    else:
        lefthip2 = np.array([0, 0])
    # 肩膀
    if right[2] is not None:
        rightshoulder2 = right[2]
    else:
        rightshoulder2 = np.array([0, 0])
    if right[5] is not None:
        leftshoulder2 = right[5]
    else:
        leftshoulder2 = np.array([0, 0])
    # 手腕
    if right[4] is not None:
        rightwrist2 = right[4]
    else:
        rightwrist2 = np.array([0, 0])
    if right[7] is not None:
        leftwrist2 = right[7]
    else:
        leftwrist2 = np.array([0, 0])
    # 肘部
    if right[3] is not None:
        rightbow2 = right[3]
    else:
        rightbow2 = np.array([0, 0])
    if right[6] is not None:
        leftbow2 = right[6]
    else:
        leftbow2 = np.array([0, 0])

    hip2 = (righthip2[1] + lefthip2[1]) / hipnum2

    realbody2 = math.fabs(hip2 - neck2[1])
    realshoulder2 = math.fabs(leftshoulder2[0] - rightshoulder2[0])
    realbow2 = (math.sqrt(
        (leftshoulder2[0] - leftbow2[0]) * (leftshoulder2[0] - leftbow2[0]) + (leftshoulder2[1] - leftbow2[1]) * (
                    leftshoulder2[1] - leftbow2[1])) + \
                math.sqrt((rightshoulder2[0] - rightbow2[0]) * (rightshoulder2[0] - rightbow2[0]) + (
                            rightshoulder2[1] - rightbow2[1]) * (rightshoulder2[1] - rightbow2[1]))) / 2
    realwrist2 = (math.sqrt(
        (leftshoulder2[0] - leftwrist2[0]) * (leftshoulder2[0] - leftwrist2[0]) + (leftshoulder2[1] - leftwrist2[1]) * (
                    leftshoulder2[1] - leftwrist2[1])) + \
                  math.sqrt((rightshoulder2[0] - rightwrist2[0]) * (rightshoulder2[0] - rightwrist2[0]) + (
                              rightshoulder2[1] - rightwrist2[1]) * (rightshoulder2[1] - rightwrist2[1]))) / 2
    realbody=(realbody1+realbody2)*height*kup/(2*heightpoint)
    realbow=(realbow1+realbow2)*height*kbow/(2*heightpoint)
    realshoulder=(realshoulder1+realshoulder2)*height*kshoulder/(2*heightpoint)
    realwrist=(realwrist1+realwrist2)*height*kwrist/(2*heightpoint)

    flag=100000
    if(sex==0):
        if (type == 0):
            for key0 in boyshortshirtsize.keys():
                flagnow = math.fabs(realbody+17 - boyshortshirtsize[key0][0]) / boyshortshirtsize[key0][0] \
                          + math.fabs(realshoulder+2 - boyshortshirtsize[key0][1]) / boyshortshirtsize[key0][1] \
                          + math.fabs(realbow-11 - boyshortshirtsize[key0][2]) / boyshortshirtsize[key0][2]
                if (flagnow < flag):
                    flag=flagnow
                    size = key0
            return realbody, realshoulder, realbow, size
        else:
            for key0 in boylongshirtsize.keys():
                flagnow = math.fabs(realbody+20 - boylongshirtsize[key0][0]) / boylongshirtsize[key0][0] \
                          + math.fabs(realshoulder+2 - boylongshirtsize[key0][1]) / boylongshirtsize[key0][1] \
                          + math.fabs(realwrist+7 - boylongshirtsize[key0][2]) / boylongshirtsize[key0][2]
                if (flagnow < flag):
                    flag = flagnow
                    size = key0
            return realbody, realshoulder, realwrist, size
    else:
        if (type == 0):
            for key0 in girlshortshirtsize.keys():
                flagnow = math.fabs(realbody - girlshortshirtsize[key0][0]) / girlshortshirtsize[key0][0] \
                          + math.fabs(realshoulder - girlshortshirtsize[key0][1]) / girlshortshirtsize[key0][1] \
                          + math.fabs(realbow - girlshortshirtsize[key0][2]) / girlshortshirtsize[key0][2]
                if (flagnow < flag):
                    flag = flagnow
                    size = key0
            return realbody, realshoulder, realbow, size
        else:
            for key0 in girllongshirtsize.keys():
                flagnow = math.fabs(realbody - girllongshirtsize[key0][0]) / girllongshirtsize[key0][0] \
                          + math.fabs(realshoulder - girllongshirtsize[key0][1]) / girllongshirtsize[key0][1] \
                          + math.fabs(realwrist - girllongshirtsize[key0][2]) / girllongshirtsize[key0][2]
                if (flagnow < flag):
                    flag = flagnow
                    size = key0
            return realbody, realshoulder, realwrist, size
#返回裤子参数
def kuzi1(left,right,height,heightpoint,type,sex):
    #胯骨
    if left[8] is not None:
        righthip1 = left[8]
    else:
        righthip1 = np.array([0, 0])
    if left[11] is not None:
        lefthip1 = left[11]
    else:
        lefthip1 = np.array([0, 0])
    #膝盖
    if left[9] is not None:
        rightknee1 = left[9]
    else:
        rightknee1 = np.array([0, 0])
    if left[12] is not None:
        leftknee1 = left[12]
    else:
        leftknee1 = np.array([0, 0])
    #脚踝
    if left[10] is not None:
        rightankle1 = left[10]
    else:
        rightankle1 = np.array([0, 0])
    if left[13] is not None:
        leftankle1 = left[13]
    else:
        leftankle1 = np.array([0, 0])
    realhip1=math.fabs(lefthip1[0]-righthip1[0])
    realknee1=(math.fabs(lefthip1[1]-leftknee1[1])+math.fabs(righthip1[1]-rightknee1[1]))/2
    realankle1=(math.fabs(lefthip1[1]-leftankle1[1])+math.fabs(righthip1[1]-rightankle1[1]))/2

    #胯骨
    if right[8] is not None:
        righthip2 = right[8]
    else:
        righthip2 = np.array([0, 0])
    if right[11] is not None:
        lefthip2 = right[11]
    else:
        lefthip2 = np.array([0, 0])
    #膝盖
    if right[9] is not None:
        rightknee2 = right[9]
    else:
        rightknee2 = np.array([0, 0])
    if right[12] is not None:
        leftknee2 = right[12]
    else:
        leftknee2 = np.array([0, 0])
    #脚踝
    if right[10] is not None:
        rightankle2 = right[10]
    else:
        rightankle2 = np.array([0, 0])
    if right[12] is not None:
        leftankle2 = right[13]
    else:
        leftankle2 = np.array([0, 0])
    realhip2=math.fabs(lefthip2[0]-righthip2[0])
    realknee2=(math.fabs(lefthip2[1]-leftknee2[1])+math.fabs(righthip2[1]-rightknee2[1]))/2
    realankle2=(math.fabs(lefthip2[1]-leftankle2[1])+math.fabs(righthip2[1]-rightankle2[1]))/2

    realhip=(realhip1+realhip2)*height*khip/(2*heightpoint)
    realankle=(realankle1+realankle2)*height*kdown/(2*heightpoint)
    realknee=(realknee1+realknee2)*height*kknee/(2*heightpoint)
    flag=100000
    if(sex==0):
        if (type == 0):
            for key0 in boyshortpantssize.keys():
                flagnow = math.fabs(realhip+5 - boyshortpantssize[key0][0]) / boyshortpantssize[key0][0] \
                          + math.fabs(realknee-27 - boyshortpantssize[key0][1]) / boyshortpantssize[key0][1]
                if (flagnow < flag):
                    flag=flagnow
                    size = key0
            return realhip, realknee, size
        else:
            for key0 in boylongpantssize.keys():
                flagnow = math.fabs(realhip+3 - boylongpantssize[key0][0]) / boylongpantssize[key0][0] \
                          + math.fabs(realankle+1.5 - boylongpantssize[key0][1]) / boylongpantssize[key0][1]
                if (flagnow < flag):
                    flag = flagnow
                    size = key0
            return realhip, realankle, size
    else:
        if (type == 0):
            for key0 in girlshortpantssize.keys():
                flagnow = math.fabs(realhip - girlshortpantssize[key0][0]) / girlshortpantssize[key0][0] \
                          + math.fabs(realknee - girlshortpantssize[key0][1]) / girlshortpantssize[key0][1]
                if (flagnow < flag):
                    flag = flagnow
                    size = key0
            return realhip, realknee, size
        else:
            for key0 in boylongpantssize.keys():
                flagnow = math.fabs(realhip - girllongpantssize[key0][0]) / girllongpantssize[key0][0] \
                          + math.fabs(realankle - girllongpantssize[key0][1]) / girllongpantssize[key0][1]
                if (flagnow < flag):
                    flag = flagnow
                    size = key0
            return realhip, realankle, size

#验证所有点是否被记录
def yanzheng(left,right):
    for n in left:
        if n is None:
            return False
    for n in right:
        if n is None:
            return False
    return True
#左右标记错误互换
def lefttoright(left,right):
    if left[2][0]<left[5][0]:
        change=left[2]
        left[2]=left[5]
        left[5]=change
    if left[3][0]<left[6][0]:
        change=left[3]
        left[3]=left[6]
        left[6]=change
    if left[4][0]<left[7][0]:
        change=left[4]
        left[4]=left[7]
        left[7]=change

    if right[2][0]<right[5][0]:
        change=right[2]
        right[2]=right[5]
        right[5]=change
    if right[3][0]<right[6][0]:
        change=right[3]
        right[3]=right[6]
        right[6]=change
    if right[4][0]<right[7][0]:
        change=right[4]
        right[4]=right[7]
        right[7]=change
    return left,right
def process():
    global interface
    global sexchose
    global type1
    global type2
    ret, im = video.read()
    w = im.shape[1]
    h = im.shape[0]
    mid = math.floor(w / 2)
    h1 = math.floor(h / 4)
    h2 = math.floor(h * 3 / 4)
    im_left = im[h1:h2, 0:mid]
    im_right = im[h1:h2, mid:w]
    im_left = cv.resize(im_left, (960, 720))
    im_right = cv.resize(im_right, (960, 720))
    sitepoints, leftpicture, rightpicture = process_photo(im_left, im_right)
    process = yanzheng(leftpicture, rightpicture)
    if process is False:
        print('请重新拍照')
        interface='F'
        pictureshow()
        sleep(Delay1*3)
        interface='D'
    leftpicture, rightpicture = lefttoright(leftpicture, rightpicture)
    height = shenggao(sitepoints) / 8.500
    if height > 190 or height < 168:
        print('请重新拍照')
        interface='F'
        pictureshow()
        sleep(Delay1 * 3)
        interface='D'
    height1 = shenggao1(leftpicture, rightpicture)
    realbody, realshoulder, realbow, size1 = shangyi1(leftpicture, rightpicture, height, height1,type1, sexchose)
    realhip, realankle, size2 = kuzi1(leftpicture, rightpicture, height, height1, type2, sexchose)
    pic1=produce(round(height,1),round(realbody,1),round(realshoulder,1),round(realbow,1),size1,round(realankle,1),round(realhip,1),size2)
    # print(realbody, ' ', realshoulder, ' ', realbow, ' ', size1)
    # print(realhip, ' ', realankle, ' ', size2)
    # print(height)
    return pic1
#图片show
def pictureshow():
    global hdmi_out
    global interface
    global num
    if(interface=='A'):
        pic='./background/A.png'
    elif(interface=='D'):
        pic='./background/D.png'
    elif(interface=='E'):
        pic='show.png'
        # img=process()
        # if img  is None:
        #     pic='./background/D.png'
    elif(interface=='F'):
        pic='anning.png'
    elif(interface=='B' or interface=='C'):
        pic='./background/'+interface+str(num)+'.png'
    # if(interface!='E'):
    img = cv.imread(pic)
    if(interface=='D'):
        ret, im = video.read()
        w = im.shape[1]
        h = im.shape[0]
        mid = math.floor(w / 2)
        h1 = math.floor(h / 4)
        h2 = math.floor(h * 3 / 4)
        # 显示在窗口上
        im_left = im[:, :]
        im_left = cv.resize(im_left, (330, 360))
        for i in range(330):
            for j in range(360):
                img[65 + j, 247 + i] = im_left[j, i]

    frame = np.array(img)
    outframe = hdmi_out.newframe()
    outframe[0:480, 0:640, :] = frame[0:480, 0:640, 0:3]
    hdmi_out.writeframe(outframe)
    if(interface=='E'):
        sleep(2)
        interface='D'
# 键扫描
def keyscan():
    global interface
    global num
    global sexchose
    global type1
    global type2
    global num1
    if (base.buttons[0].read() == 1):
        if(interface=='B'):
            interface='C'
            num1=num
        elif(interface=='C'):
            num2=num
            interface='D'
        elif(interface=='D'):
            interface='E'
        pictureshow()
        sleep(Delay1)
    elif (base.buttons[1].read() == 1):
        if(interface=='A'):
            interface='B'
            sexchose=0
        else:
            num=(num-1) % 6
            if(interface=='B'):
                type1=int(num/3)
            if(interface=='C'):
                type2=int(num/3)
            if(interface=='D'):
                interface='F'
                sleep(2)
        pictureshow()
        sleep(Delay1)
    elif (base.buttons[2].read() == 1):
        if(interface=='A'):
            interface='B'
            sexchose=1
        else:
            num=(num+1) % 6
            if(interface=='B'):
                type1=int(num/3)
            if(interface=='C'):
                type2=int(num/3)
        pictureshow()
        sleep(Delay1)
    elif (base.buttons[3].read() == 1):
        if (interface=='B') :
            interface='A'
        elif(interface=='C'):
            interface=='B'
        elif(interface=='D'):
            interface=='C'
        elif(interface=='E'):
            interface=='A'
        pictureshow()
        sleep(Delay1)
#produce
def produce(x1,x2,x3,x4,x5,x6,x7,x8):
    # 加载背景图片

    img = cv.imread("show.png")
    clothup=cv.imread('./clothes/B'+num1+'.png')
    clothdowm= cv.imread('./clothes/C'+num2+'.png')
    for n1 in range(200):
        for n2 in range(200):
            if(clothup[n1 , n2]!=0):
                img[ 20+n1 , 50+n2]= clothup[n1 , n2]
            if(clothdowm[n1, n2]!=0):
                img[ 260+n1, 50+n2] = clothdowm[n1, n2]
    # 设置需要显示的字体
    fontpath = "font/simsun.ttc"
    font = ImageFont.truetype(fontpath, 24)
    img_pil = Image.fromarray(img)
    draw = ImageDraw.Draw(img_pil)

    # 绘制文字信息
    draw.text((300, 50), "身高", font=font, fill=(0, 0, 0))
    draw.text((500, 50), str(x1), font=font, fill=(0, 0, 0))

    draw.text((300, 100), "身长", font=font, fill=(0, 0, 0))
    draw.text((500, 100), str(x2), font=font, fill=(0, 0, 0))

    draw.text((300, 140), "肩宽", font=font, fill=(0, 0, 0))
    draw.text((500, 140), str(x3), font=font, fill=(0, 0, 0))
    
    draw.text((300, 180), "袖长", font=font, fill=(0, 0, 0))
    draw.text((500, 180), str(x4), font=font, fill=(0, 0, 0))

    draw.text((300, 220), "上衣推荐尺寸", font=font, fill=(0, 0, 0))
    draw.text((500, 220), x5+'码', font=font, fill=(0, 0, 0))

    draw.text((300, 300), "腿长", font=font, fill=(0, 0, 0))
    draw.text((500, 300), str(x6), font=font, fill=(0, 0, 0))

    draw.text((300, 340), "胯宽", font=font, fill=(0, 0, 0))
    draw.text((500, 340), str(x7), font=font, fill=(0, 0, 0))

    draw.text((300, 380), "下衣推荐尺寸", font=font, fill=(0, 0, 0))
    draw.text((500, 380), x8+'码', font=font, fill=(0, 0, 0))
    return img_pil
if __name__ == '__main__':
    #数据初始化
    interface = 'A'
    num = 0
    num1=0
    num2=0
    sexchose = 0
    Delay1 = 0.3
    type1 = 0
    type2 = 0

    base = BaseOverlay("base.bit")
    Mode = VideoMode(640, 480, 24)
    hdmi_out = base.video.hdmi_out
    hdmi_out.configure(Mode, PIXEL_BGR)
    hdmi_out.start()
    pictureshow()
    video = cv.VideoCapture(0)
    while(True):
        keyscan()
        if(interface=='D'):
            pictureshow()

from pynq.overlays.base import BaseOverlay
base = BaseOverlay("base.bit")
pAudio = base.audio
pAudio.set_volume(60)
pAudio = base.audio

pAudio.load("sound/voice1.wav")
pAudio.play()
pAudio.load("sound/voice2.wav")
pAudio.play()
pAudio.load("sound/voice3.wav")
pAudio.play()
pAudio.load("sound/voice4.wav")
pAudio.play()
pAudio.load("sound/voice5.wav")
pAudio.play()
pAudio.load("sound/voice6.wav")
pAudio.play()
print('end')